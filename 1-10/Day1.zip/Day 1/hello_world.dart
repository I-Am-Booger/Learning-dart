void main() {
  print('Hello, My name is Booger!');
  print('I am the coolest guy in the world!');
  print(
    'My wife is the most wonderful women in the world even if she is not nice to Trump!',
  );
  print('I love picking on her!!!');
  print('I love my cat, Nola!!!');
}
