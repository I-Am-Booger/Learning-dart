void main() {
  int a = 10;
  int b = 3;

  print('Addition: 10 + 3 = ${a + b}');
  print('Subtraction: 10 - 3 = ${a - b}');
  print('Multiplication: 10 * 3 = ${a * b}');
  print('Division (double): 10 / 3 = ${a / b}');
  print('Integer division: 10 / 3 = ${a ~/ b}');
  print('Remainder: 10 % 3 = ${a % b}');
}
