void main() {
  double nolaWeight = 5.8;
  int roundedWeight = nolaWeight.toInt();
  double myWeight = 178.9;
  int roundedWeightMe = myWeight.round();

  double num1 = 5.8;
  int num1_ceil = num1.ceil();
  double num2 = 5.7;
  int num2_floor = num2.floor();

  print('Rounded cat weight: $roundedWeight lbs');
  print('Rounded Gant Weight to the nearest lb: $roundedWeightMe');
  print(
    'We are going to take 5.8 and round it to the next number up $num1_ceil calling the number allready rounded up.',
  );
  print(
    'We are going to do the same thing in the code: ${num1_ceil.ceil()}',
  ); // It negative numbers this would go to -5
  print(
    'We are going to take 5.7 and round it down to the lower number with the var $num2_floor calling the aready made var rounded down.',
  );
  print(
    'The same thing in code ${num2.floor()}',
  ); // in negative numbers this would go to -6
}
