import 'dart:math';

void main() {
  int age = 45;
  int favoriteNumber = 7;
  double luckyFraction = 2.5;

  print(
    'Did you know that is you multiply my age by $favoriteNumber, you get ${age * favoriteNumber}?',
  );
  print('Half of my favorite number is ${favoriteNumber / 2}');
  print(
    'If you raise $favoriteNumber to the power of 2, it becomes ${pow(favoriteNumber, 2)}',
  );
  print("What's cooler than being cool? ${luckyFraction * favoriteNumber}");
}
