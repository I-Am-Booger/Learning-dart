void main() {
  String name = "Gant";
  int age = 45;
  String favoriteDrink = 'Birch Bear';
  bool learningCoding = true;
  String nolaName = 'Nola';
  double nolaWeight = 4.8;
  String queston = learningCoding ? 'Keep up the great work!' : 'Why not';

  String bio = ''' 
  Bio:
  So my name is $name,
  and my age is $age.
  My favorite drink is $favoriteDrink, 
  and I am learning to code: $learningCoding.
  My cats name is $nolaName and her weight is $nolaWeight 
    
  Rounded Results
  Nola's weight rounded to the nearest lb: ${nolaWeight.round()}
  My weight rounded to the nearest lb: ${(179.8).round()}
  5.8 rounded up: ${(5.8).ceil()}
  5.7 rounded down: ${(5.7).floor()}
  
  Learning Status: $queston

  Negative Number Test:
  Ceil of -5.7 is ${(-5.7).ceil()}
  Floor of -5.7 is ${(-5.7).floor()} 
  ''';
  print(bio);
}
