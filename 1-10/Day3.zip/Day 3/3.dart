import 'dart:math';

void main() {
  double x = sqrt(16); // square root
  num y = pow(2, 3);

  print('The square root of 16 is $x');
  print('2 to the power of 3 is $y');

  print(min(5, 10));
  print(max(5, 10));
}
