void main() {
  int myAge = 45;
  double pi = 3.14;

  print('My age is $myAge');
  print('The value of pi is $pi');
}
