/*void main() {
  greet();
}

void greet() {
  print("Hello, Booger");
}*/

/*void main() {
  sayHelloTo("Gant");
}

void sayHelloTo(String name) {
  print('Hey there, $name!');
}
int add(int a, int b) {
  return a + b;
}

void main() {
  print("${add(1, 3)}");
}*/
void main() {
  int add(int a, int b) {
    return a + b;
  }

  int result = add(3, 4);

  print(result);
}
