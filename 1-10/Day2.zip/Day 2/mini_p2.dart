/// 2 different versions of the same program

// original version
/*void main() {
  String name = 'Booger';
  int age = 45;
  String favoriteDrink = 'Sweet Tea';
  bool likesCoding = true;
  String pet = 'Nola';

  String bio = '''
  Name: $name
  Age: $age
  favorite Drink: $favoriteDrink
  likes Coding?: $likesCoding
  Pet's Name: $pet
  ''';

  print(bio);
}

*/
// second version
void main() {
  String name = 'Gant'; // A string with the value of Gant
  int age = 45; // A int with the value of my age
  String favoriteDrink = 'Birch Beer'; // A string with my favorite soda;
  bool learningCoding =
      true; // a bool with the value of if I am learning coding
  String pet = 'Nola'; // String with my cats name

  String bio = ''' 
  So my name is $name,
  I am the wonderful age of $age,
  So I am kind of old. 
  I love to drink some $favoriteDrink, 
  while I am coding: $learningCoding.
  My sweet cat $pet is laying by my feet. 
  ''';

  print(bio);

  print('$pet loves catnip, yes she does!');

  if (learningCoding == true) {
    print('I am learning Dart!');
  } else {
    print('I need to learn some dart!');
  }
}
