void main() {
  String name = "Booger"; // Stores a name
  int age = 45; // Stores an integer
  double height = 5.8; // Stores a decimal number
  bool isCool = true; // Stores true/false... a bollean

  print('Name: $name');
  print('Age: $age');
  print('Height: $height feet');
  print('Is Booger cool? $isCool');
}
