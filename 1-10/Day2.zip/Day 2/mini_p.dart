///Two different Version of the same program the original
///and then the sequal

// Original version

/*void main() {
  final favoriteColor = "Black";
  double height = 5.8;

  String message = '''
Hello there, I am Booger!
My favorite color is $favoriteColor.
My height is $height feet tall.
''';

  print(message);
  print("String: My nickname is $favoriteColor Booger.");
}*/

// The sequal
void main() {
  final favMovie = 'The Matrix';
  final catsName = 'Nola';
  double catsWeight =
      5; //I know this is not a double but when it's looked at it will become a double.

  String message = '''
  So I think my favorite movie is $favMovie
  it used to be American Beauty but things change.
  I love my cat $catsName, she is only $catsWeight lbs. 
''';
  print(message);
}
