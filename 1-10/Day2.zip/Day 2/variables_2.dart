void main() {
  String name = 'Booger'; // Makes a String var
  int age = 45; // Makes a int var
  String favoriteSnack = 'Candy';
  String pet = 'Nola';
  bool isMarried = true;
  const pi = 3.14;
  var something = 'A string';
  var something2 = 2;

  print('String: My name is $name');
  print('int: I am $age');
  print('String: My favorite snack is $favoriteSnack.');
  print("String: My cat's name is $pet");
  print('Bool: AM I married? $isMarried');
  print('Const: What is the number value of pie? $pi');
  print(
    'A var is a variable that is somewhat dynamic when nameing but is not afterwords.' +
        ' 2 examples are $something or $something2 they cannot be changed afterwords to a different type after being declared.',
  );
}
