void main() {
  Map<String, String> capitals = {
    'USA': 'Washington D.C.',
    'France': 'Paris',
    'Japan': 'Tokyo',
  };
  print(capitals['France']); // Outputs Paris

  capitals['Germany'] = 'Berlin';
  print(capitals);
  capitals.remove('Japan');
  print(capitals);
  print(capitals.length);
}
