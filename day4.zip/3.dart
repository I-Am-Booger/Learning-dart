void main() {
  Set<String> animals = {'Cat', 'Dog', 'Bird'};
  animals.add('Cat');
  print(animals);
  animals.remove('Cat');
  print(animals);
}
