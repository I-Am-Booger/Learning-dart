void main() {
  List<String> snacks = ['Chips', 'Candy', 'Pizza'];
  print(snacks[0]);
  print(snacks[1]);
  print(snacks[2]);

  snacks.add('Popcorn');
  print(snacks[3]);
  print(snacks);
  print(snacks.length);
}
