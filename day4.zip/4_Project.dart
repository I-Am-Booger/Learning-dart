void main() {
  List<String> favoriteSnacks = ['Candy', 'Pizza', 'Cocain'];
  Set<String> names = {'Nola', 'Nola', 'Nola', 'Nola'};
  Map<String, int> programming = {'Dart': 10, 'Lua': 10, 'Zig': 2};

  print(favoriteSnacks);
  print(names);
  print(programming);

  print('My favorite snack is ${favoriteSnacks[2]}!');
  print('My pets name is $names');

  programming.forEach((lang, rating) {
    print('- $lang: $rating');
  });
}
