void main() {
  List<String> snacks = ['chips', 'Candy', 'Pizza'];
  print(snacks[1]);
}
